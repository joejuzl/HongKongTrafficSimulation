/*
 * TERMS AND CONDITIONS
 * 
 * Please note that,
 * 
 * This sample program remains the property of, and may not be reproduced in
 * whole or in part without the express permission of the Government of the
 * Hong Kong Special Administrative Region (HKSARG).  Information provided by
 * this sample program and all the associated intellectual property rights are
 * retained by HKSARG.
 * 
 * Users may use this sample program for the purpose of designing, developing,
 * testing and running of their applications.  By using this sample program,
 * users agree not to sue HKSARG and agree to indemnify, defend and hold
 * harmless HKSARG, its officers and employees from any and all third party
 * claims, liability, damages and/or costs (including but not limited to,
 * legal fees) arising from the use of this sample program.
 * 
 * HKSARG will not be liable for any direct, indirect, incidental, special or
 * consequential damages of any kind resulting from the use of or inability to
 * use this sample program and information provided.
 * 
 * DISCLAIMER
 * 
 * Refer to http://www.gov.hk/en/about/disclaimer.htm
 */

/*
 * BUILD INSTRUCTIONS (assuming Axis2 is used):
 * 
 * 1. Install Apache Axis2 (http://axis.apache.org/axis2/java/core/)
 * 2. Install Apache Ant (http://ant.apache.org/)
 * 3. Run WSDL2Java against the WSDL document:
 *        wsdl2java -wv 2 -uri http://data.one.gov.hk/wsdl/td/journeytime.wsdl
 * 4. Build service client jar (JourneyTime-test-client.jar):
 *        ant
 * 5. Compile the program with all Axis2 jars and generated service client jar
 *        (the following example is for JDK6 in Windows environment) 
 *        javac -classpath build\lib\JourneyTime-test-client.jar;%AXIS2_HOME%\lib\*; JourneyTimeClient.java
 */

import hk.gov.one.data.td.*;
import hk.gov.one.data.td.JourneyTimeStub.*;

/*
 * Take location ID as parameter and output all corresponding destination
 * with journey data
 */

public class JourneyTimeClient {
	
	public static void main(String[] args) {
		
		try {

			/* retrieve input parameter */
			
			if (args.length != 1) {
				System.out.println("one parameter required");
				System.exit(1);
			}
			String targetLocationId = args[0];
			
			/* retrieve XML data */

			JourneyTimeStub stub = new JourneyTimeStub();
			Jtis_journey_list response = stub.getJourneyTime();
			
			/* display result */
		
			Jtis_journey_listSequence[] entries = response.getJtis_journey_listSequence();
			
			for (Jtis_journey_listSequence entry: entries) {
				String locationId = entry.getJtis_journey_time().getLOCATION_ID();
				
				if (locationId.equals(targetLocationId)) {					
					System.out.print("Destination " + entry.getJtis_journey_time().getDESTINATION_ID() + ": ");
					
					int journeyType = entry.getJtis_journey_time().getJOURNEY_TYPE().intValue();
					switch (journeyType) {
					case 1:
						System.out.println(entry.getJtis_journey_time().getJOURNEY_DATA() + " min");
						break;
					case 2:
						int journeyData = entry.getJtis_journey_time().getJOURNEY_DATA().intValue();
						switch (journeyData) {
						case 1:
							System.out.println("traffic congested");
							break;
						case 2:
							System.out.println("tunnel congested");
							break;
						case 3:
							System.out.println("tunnel closed");
							break;
						case 4:
							System.out.println("blank");
							break;
						case -1:
							System.out.println("not applicable");
							break;
						}
						break;
					}
				}
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
