/*
 * TERMS AND CONDITIONS
 * 
 * Please note that,
 * 
 * This sample program remains the property of, and may not be reproduced in
 * whole or in part without the express permission of the Government of the
 * Hong Kong Special Administrative Region (HKSARG).  Information provided by
 * this sample program and all the associated intellectual property rights are
 * retained by HKSARG.
 * 
 * Users may use this sample program for the purpose of designing, developing,
 * testing and running of their applications.  By using this sample program,
 * users agree not to sue HKSARG and agree to indemnify, defend and hold
 * harmless HKSARG, its officers and employees from any and all third party
 * claims, liability, damages and/or costs (including but not limited to,
 * legal fees) arising from the use of this sample program.
 * 
 * HKSARG will not be liable for any direct, indirect, incidental, special or
 * consequential damages of any kind resulting from the use of or inability to
 * use this sample program and information provided.
 * 
 * DISCLAIMER
 * 
 * Refer to http://www.gov.hk/en/about/disclaimer.htm
 */

/*
 * BUILD INSTRUCTIONS (assuming Axis2 is used):
 * 
 * 1. Install Apache Axis2 (http://axis.apache.org/axis2/java/core/)
 * 2. Install Apache Ant (http://ant.apache.org/)
 * 3. Run WSDL2Java against the WSDL document:
 *        wsdl2java -wv 2 -uri http://data.one.gov.hk/wsdl/td/cctvimage.wsdl
 * 4. Build service client jar (CctvImage-test-client.jar):
 *        ant
 * 5. Compile the program with all Axis2 jars and generated service client jar
 *        (the following example is for JDK6 in Windows environment) 
 *        javac -classpath build\lib\CctvImage-test-client.jar;%AXIS2_HOME%\lib\*; CctvImageClient.java
 * 
 * Note: This sample program requires mapping file imagelist.xml
 */

import java.io.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import hk.gov.one.data.td.*;
import hk.gov.one.data.td.CctvImageStub.*;

/*
 * Download all images from a selected region
 */

public class CctvImageClient {

	/*
	 * Download image by key
	 */
	
	private static void getImage(String key) throws Exception {

		Request req = new Request();
		req.setKey(key);
		CctvImageStub stub = new CctvImageStub();
		Image response = stub.getCctvImage(req);
		
		String name = response.getName();
		response.getData().writeTo(new FileOutputStream(name));
	}
	
	/*
	 * Main program
	 */
	public static void main(String[] args) {
		
		String[] regions = {
				"Hong Kong Island",
				"Kowloon",
				"Tsuen Wan",
				"Tuen Mun & Tin Shui Wai",
				"Tai Po, North & Yuen Long",
				"Shatin & Ma On Shan",
				"Lantau"
		};
		
		String MAPPING_FILE = "imagelist.xml";
		
		try {

			/* input target region */
			
			for (int i = 0; i < regions.length; i++) {
				System.out.println(i + ": " + regions[i]);
			}
			System.out.print("Select a region: ");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String input = br.readLine();
			String targetRegion = regions[Integer.parseInt(input)];
			
			/* parse mapping file */
			
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			Document doc = factory.newDocumentBuilder().parse(MAPPING_FILE);
			NodeList nodes = doc.getElementsByTagName("image");
			
			for (int i = 0; i < nodes.getLength(); i++) {
				
				Node node = nodes.item(i);
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					
					Element image = (Element)node;
					NodeList regionNodeList = image.getElementsByTagName("english-region");
					String region = ((Element)regionNodeList.item(0)).getChildNodes().item(0).getNodeValue();
					
					if (region.equals(targetRegion)) {
						
						NodeList keyNodeList = image.getElementsByTagName("key");
						String key = ((Element)keyNodeList.item(0)).getChildNodes().item(0).getNodeValue();

						/* Call download routine */
						
						System.out.println("Key=" + key + ", downloading...");
						getImage(key);
					}
				}
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
