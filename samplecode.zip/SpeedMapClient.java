/*
 * TERMS AND CONDITIONS
 * 
 * Please note that,
 * 
 * This sample program remains the property of, and may not be reproduced in
 * whole or in part without the express permission of the Government of the
 * Hong Kong Special Administrative Region (HKSARG).  Information provided by
 * this sample program and all the associated intellectual property rights are
 * retained by HKSARG.
 * 
 * Users may use this sample program for the purpose of designing, developing,
 * testing and running of their applications.  By using this sample program,
 * users agree not to sue HKSARG and agree to indemnify, defend and hold
 * harmless HKSARG, its officers and employees from any and all third party
 * claims, liability, damages and/or costs (including but not limited to,
 * legal fees) arising from the use of this sample program.
 * 
 * HKSARG will not be liable for any direct, indirect, incidental, special or
 * consequential damages of any kind resulting from the use of or inability to
 * use this sample program and information provided.
 * 
 * DISCLAIMER
 * 
 * Refer to http://www.gov.hk/en/about/disclaimer.htm
 */

/*
 * BUILD INSTRUCTIONS (assuming Axis2 is used):
 * 
 * 1. Install Apache Axis2 (http://axis.apache.org/axis2/java/core/)
 * 2. Install Apache Ant (http://ant.apache.org/)
 * 3. Run WSDL2Java against the WSDL document:
 *        wsdl2java -wv 2 -uri http://data.one.gov.hk/wsdl/td/speedmap.wsdl
 * 4. Build service client jar (SpeedMap-test-client.jar):
 *        ant
 * 5. Compile the program with all Axis2 jars and generated service client jar
 *        (the following example is for JDK6 in Windows environment) 
 *        javac -classpath build\lib\SpeedMap-test-client.jar;%AXIS2_HOME%\lib\*; SpeedMapClient.java
 */

import hk.gov.one.data.td.*;
import hk.gov.one.data.td.SpeedMapStub.*;

/*
 * Take a number as parameter and output all link ID with traffic speed
 * lower than the number
 */

public class SpeedMapClient {
	
	public static void main(String[] args) {
		
		try {

			/* parse input parameter */
			
			if (args.length != 1) {
				System.out.println("one parameter required");
				System.exit(1);
			}
			int threshold = Integer.parseInt(args[0]);
			
			/* retrieve XML data */

			SpeedMapStub stub = new SpeedMapStub();
			Jtis_speedlist response = stub.getSpeedMap();
			
			/* display result */
		
			Jtis_speedlistSequence[] entries = response.getJtis_speedlistSequence();
			
			for (Jtis_speedlistSequence entry: entries) {
				
				int trafficSpeed = entry.getJtis_speedmap().getTRAFFIC_SPEED().intValue();
				
				if (trafficSpeed < threshold) {
					System.out.println(entry.getJtis_speedmap().getLINK_ID() + ": " + trafficSpeed);
				}
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
